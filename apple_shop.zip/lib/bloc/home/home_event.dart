abstract class HomeEvent {}

class HomeGetInitilzeData extends HomeEvent {}
