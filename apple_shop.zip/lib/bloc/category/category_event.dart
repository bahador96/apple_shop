abstract class CategoryEvent {}

class CategoryRequestList extends CategoryEvent {}
